#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <fcntl.h>
#include <signal.h>

#include "clientsensor.h"
#define MAIN_H
#include "color_sensor.h"
#include "accelerometer.h"

#define MQTT_HOST "192.168.1.44"
#define MQTT_PORT 1883
#define MQTT_TOPIC "v1/devices/me/telemetry"
#define MQTT_USERNAME "BIXvoxrKql0mLwyKNojJ"

#define DATA_COUNT         10
#define TIME_BETWEEN_MEASURES 1

void *start_accelerometer();
void *start_color_sensor(ColorData *colorData);
void collectSensorData(SensorData *data);
void init_signals();
void sigint_handler(int signum);
void destroy_signals();

pthread_t thread_color_sensor, thread_acc;
int thread_error;
uint8_t color_sensor_alive, accelerometer_alive;

atomic_int color_sensor_data_ready = 0;
atomic_int acc_data_ready = 0;

ColorData colorData = {0};
float ax, ay, az;

struct termios original_termios = {0}, modified_termios = {0};
struct mosquitto *mosq;

int main() {
    mosquitto_lib_init();

    mosq = mosquitto_new(NULL, true, NULL);
    if (!mosq) {
        fprintf(stderr, "Errore: Impossibile creare l'istanza Mosquitto\n");
        return 1;
    }

    mosquitto_username_pw_set(mosq, MQTT_USERNAME, NULL);

    int mqtt_error = mosquitto_connect(mosq, MQTT_HOST, MQTT_PORT, 0);
    if (mqtt_error != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Errore: Impossibile connettersi al broker MQTT. Codice di ritorno = %d\n", mqtt_error);
        mosquitto_destroy(mosq);
        mosquitto_lib_cleanup();
        return 1;
    }

    init_signals();

    pthread_create(&thread_color_sensor, NULL, start_accelerometer, NULL);
    accelerometer_alive = 1;
    pthread_create(&thread_acc, NULL, start_color_sensor, &colorData);
    color_sensor_alive = 1;

    while (1) {
        usleep(10000);

        if (atomic_load(&acc_data_ready) && atomic_load(&color_sensor_data_ready)) {
            SensorData sensor_data[DATA_COUNT];
            collectSensorData(sensor_data);

            time_t current_time = time(NULL);

            for (int i = 0; i < DATA_COUNT; i++) {
                char mqtt_message[512];
                snprintf(mqtt_message, sizeof(mqtt_message), "{\"time\": %ld, \"acceleration_x\": %.2f, \"acceleration_y\": %.2f, \"acceleration_z\": %.2f, \"red\": %.2f, \"green\": %.2f, \"blue\": %.2f}",
                    current_time, sensor_data[i].acceleration_x, sensor_data[i].acceleration_y, sensor_data[i].acceleration_z, sensor_data[i].red, sensor_data[i].green, sensor_data[i].blue);

                mqtt_error = mosquitto_publish(mosq, NULL, MQTT_TOPIC, strlen(mqtt_message), mqtt_message, 1, false);
                if (mqtt_error != MOSQ_ERR_SUCCESS) {
                    fprintf(stderr, "Errore: Impossibile pubblicare il messaggio MQTT. Codice di ritorno = %d\n", mqtt_error);
                } else {
                    printf("Messaggio MQTT inviato: %s\n", mqtt_message); // Stampa del messaggio MQTT inviato
                }
            }
        }
    }

    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    destroy_signals();

    return 0;
}

void *start_accelerometer() {
    acceleration();
    return NULL;
}

void *start_color_sensor(ColorData *colorData) {
    colors(colorData);
    return NULL;
}

void collectSensorData(SensorData *data) {
    for (int i = 0; i < DATA_COUNT; i++) {
        data[i].red = colorData.red;
        data[i].green = colorData.green;
        data[i].blue = colorData.blue;
        data[i].acceleration_x = ax;
        data[i].acceleration_y = ay;
        data[i].acceleration_z = az;
        sleep(TIME_BETWEEN_MEASURES);
    }
}

void init_signals() {
    tcgetattr(STDIN_FILENO, &original_termios);
    modified_termios = original_termios;
    modified_termios.c_lflag &= ~(ICANON | ECHO);
    modified_termios.c_cc[VMIN] = 0;
    modified_termios.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &modified_termios);
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    flags |= O_NONBLOCK;
    fcntl(STDIN_FILENO, F_SETFL, flags);
    signal(SIGINT, sigint_handler);
}

void sigint_handler(int signum) {
    printf("Exiting, wait until everything is closed...\n");
    if (accelerometer_alive) {
        accelerometer_alive = 0;
        stop_acc_measurements(1);
    }
    if (color_sensor_alive) {
        color_sensor_alive = 0;
        exit_handler(1);
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &original_termios);
    sleep(1);
    exit(1);
}

void destroy_signals() {
    tcsetattr(STDIN_FILENO, TCSANOW, &original_termios);
}

